# DeveloperMenu
Enable Developer Menu

Developer Mode
Mod Type: Server

How to use:

-Install mod

-Type -dev +developer 1 into ns_startup_args.txt

-Console type sv_cheat 1

-Enter the match,Press ESC key to open in game menu(The first image show where it's )


Note:
-Most of the command still need fix.
